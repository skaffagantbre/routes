module.exports = {
    
    getPosts(req, res) {
    
    },
    addPost(req, res) {
    
    },
    updatePost(req, res) {
    
    },
    removePost(req, res) {
    
    }
}